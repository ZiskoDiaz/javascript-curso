import {PI} from "./constantes.js"
import {aritmetica as calcula} from "./aritmetica.js";
console.log(PI)
console.log(calcula.sumar(1,2))
console.log(calcula.restar(1,2))
console.log(calcula.multiplicar(1,2));
console.log(calcula.dividir(1,2));