export const PI = Math.PI;

const hello = () => {
    console.log("Hello");
}